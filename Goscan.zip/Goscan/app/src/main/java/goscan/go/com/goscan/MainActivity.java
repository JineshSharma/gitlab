package goscan.go.com.goscan;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView=(TextView)findViewById(R.id.msg);
        try {
            checkMobileVersion();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
        integrator.setPrompt("Scan a barcode");
        integrator.setCameraId(0);  // Use a specific camera of the device
        integrator.setBeepEnabled(false);
        integrator.setBarcodeImageEnabled(true);
        integrator.initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(result != null) {
            if(result.getContents() == null) {
                textView.setText("Cancelled");
            } else {
                textView.setText("Scanned: " + result.getContents());
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void checkMobileVersion() throws JSONException {
        if(Build.VERSION.SDK_INT >= 23) {
            this.allowUserPermissions();
        }
    }



    @TargetApi(23)
    private void allowUserPermissions() throws JSONException {
        ArrayList permissionsNeeded = new ArrayList();
        final ArrayList permissionsList = new ArrayList();
        if(!this.addPermission(permissionsList, "android.permission.ACCESS_WIFI_STATE")) {
            permissionsNeeded.add("Access Wifi State");
        }
        if(!this.addPermission(permissionsList, "android.permission.ACCESS_NETWORK_STATE")) {
            permissionsNeeded.add("Read Contacts");
        }
        if(!this.addPermission(permissionsList, "android.permission.INTERNET")) {
            permissionsNeeded.add("Write Contacts");
        }
        if(!this.addPermission(permissionsList, "android.permission.CAMERA")) {
            permissionsNeeded.add("Write Contacts");
        }

        if(permissionsList.size() <= 0) {
            //========================

            //========================
        } else if(permissionsNeeded.size() <= 0) {
            this.requestPermissions((String[])permissionsList.toArray(new String[permissionsList.size()]), 124);
        } else {
            String message = "You need to grant access to " + (String)permissionsNeeded.get(0);
            for(int i = 1; i < permissionsNeeded.size(); ++i) {
                message = message + ", " + (String)permissionsNeeded.get(i);
            }
            this.showMessageOKCancel(message, new android.content.DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    requestPermissions((String[])permissionsList.toArray(new String[permissionsList.size()]), 124);
                }
            });
        }
    }

    @TargetApi(23)
    private boolean addPermission(List<String> permissionsList, String permission) {
        if(this.checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            permissionsList.add(permission);
            if(!this.shouldShowRequestPermissionRationale(permission)) {
                return false;
            }
        }
        return true;
    }

    private void showMessageOKCancel(String message, android.content.DialogInterface.OnClickListener okListener) {
        (new AlertDialog.Builder(this)).setMessage(message).setPositiveButton("ok", okListener).create().show();
    }

    public void showAlertDialog(String message, final String responseCode) {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.custom_common_dialog_one__sdk);
        TextView text = (TextView) dialog.findViewById(R.id.dialocontent);
        text.setText(message);
        dialog.show();
        Button declineButton = (Button) dialog.findViewById(R.id.btn_success);
        declineButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog.dismiss();
                // finish();
            }
        });

    }

}
